import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef([]);

  const handleClick = () => {
    for (let i = 0; i < inputRefs.current.length; i++) {
      if (inputRefs.current[i].value === '') {
        inputRefs.current[i].focus();
        break;
      }
    }
  };

  return (
    <>
      {Array.from({ length: 10 }, (_, index) => (
        <div style={{ display: 'block' }} key={index}>
          Input {index + 1}: <input type='text' ref={el => inputRefs.current[index] = el} />
        </div>
      ))}
      <button type='button' onClick={handleClick}>I'm a button</button>
    </>
  );
}

export default Problem3;