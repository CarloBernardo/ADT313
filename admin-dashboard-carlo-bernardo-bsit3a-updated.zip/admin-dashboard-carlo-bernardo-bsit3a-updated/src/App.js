import logo from './logo.svg';
import './App.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import LoginPage from './pages/Public/Login/LoginPage';
import RegisterPage from './pages/Public/Register/RegisterPage';
import Main from './pages/Main/Main';
import Dashboard from './pages/Main/Dashboard/Dashboard';

const router = createBrowserRouter([
  
  { path: '/',
    element: <LoginPage/>,
  },
  {
    path: '/register',
    element: <RegisterPage/>,
  },
  {
    path: 'adminmode/login',
    element: <LoginPage/>,
  },
  {
    path: '/main',
    element: <Main/>,
    children: [
  {
    path: '/main/dashboard',
    element: <Dashboard/>,
  }]
}
])
function App() {
  return (
    <div className="App">
      <RouterProvider router={router}/>
    </div>
  );
}

export default App;
